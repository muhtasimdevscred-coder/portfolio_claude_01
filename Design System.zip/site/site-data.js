/* ═══════════════════════════════════════════════════
   MUHTASIM AHMED — Site Data Layer
   All content lives here. Pages read from localStorage,
   falling back to DEFAULT_DATA.
═══════════════════════════════════════════════════ */

const DEFAULT_DATA = {
  global: {
    name: "Muhtasim Ahmed",
    logo: "M·A",
    tagline: "Creative Freelancer",
    available: true,
    email: "hello@muhtasimahmed.dev",
    location: "Dhaka, Bangladesh",
    timezone: "UTC+6",
    copyright: "© 2026 · DHAKA, BANGLADESH",
    profileImg: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=700&q=80&fit=crop&crop=faces,top",
    socials: [
      { name: "Twitter / X", handle: "@muhtasim", icon: "𝕏", url: "#" },
      { name: "Dribbble",    handle: "muhtasim",  icon: "◉", url: "#" },
      { name: "LinkedIn",    handle: "muhtasim",  icon: "in", url: "#" },
      { name: "GitHub",      handle: "muhtasim",  icon: "⌥", url: "#" }
    ],
    accentInd:  "#6366f1",
    accentCyan: "#06b6d4",
    accentPink: "#ec4899"
  },
  home: {
    hero: {
      tag:   "// AVAILABLE FOR WORK",
      line1: "Muhtasim",
      line2: "Ahmed",
      desc:  "I design and build digital experiences at the intersection of craft and code — turning complex problems into elegant, high-performance solutions.",
      btn1:  "VIEW MY WORK",
      btn2:  "HIRE ME →"
    },
    stats: [
      { num: "42+", label: "PROJECTS" },
      { num: "28+", label: "CLIENTS" },
      { num: "6+",  label: "YEARS EXP" }
    ],
    services: [
      { icon: "◻", title: "UI/UX Design",      desc: "Research-driven interfaces built for clarity and conversion.",              accent: "ind" },
      { icon: "⚡", title: "Frontend Dev",       desc: "Performant, accessible front-end code. React, Next.js, TypeScript.",        accent: "cya" },
      { icon: "◈", title: "Brand Identity",     desc: "Complete visual identity systems that make brands unforgettable.",          accent: "pnk" }
    ],
    aboutTitle: "I craft digital products people actually love.",
    aboutText:  "With 6+ years in design and development, I bring ideas from napkin sketch to polished product. I work with startups, agencies, and founders who care deeply about what they're building.",
    testimonials: [
      { quote: "Muhtasim delivered beyond expectations — the design system he built is still powering our product 2 years later.", author: "Sara K.", role: "CEO, NovaTech" },
      { quote: "Working with him felt like having a co-founder who happened to be a world-class designer.", author: "James T.", role: "Founder, Orbital" }
    ]
  },
  about: {
    hero: {
      tag:    "// ABOUT ME",
      title1: "The Person",
      title2: "Behind the Work",
      bio:    "I'm Muhtasim Ahmed — a freelance creative building digital experiences at the edge of design and code. Based in Dhaka, working with clients across the globe to make things that feel like they came from a different timeline.",
      chips:  ["UI/UX DESIGN", "FRONTEND DEV", "BRAND IDENTITY", "DHAKA, BD"],
      stats:  [
        { num: "42+", label: "PROJECTS" },
        { num: "28+", label: "CLIENTS" },
        { num: "6+",  label: "YEARS EXP" },
        { num: "12+", label: "COUNTRIES" }
      ]
    },
    story: {
      p1: "I fell in love with design when I was 16, tinkering with HTML on a secondhand laptop. What started as a hobby quickly became an obsession — how do you make something that not only works, but feels extraordinary?",
      p2: "After years of sharpening my skills across agencies, startups, and late nights on personal projects, I went full-time freelance in 2022. Since then I've collaborated with fintech companies, SaaS platforms, e-commerce brands, and creative studios across 12 countries.",
      p3: "My philosophy is simple: design is problem-solving with aesthetics. Every pixel serves a purpose, every interaction earns its place.",
      signature: "— Muhtasim Ahmed"
    },
    values: [
      { num: "01 / QUALITY",  title: "Craft over speed",     desc: "I'd rather take an extra day to get it right than ship something merely 'good enough.'",                    accent: "ind" },
      { num: "02 / CLARITY",  title: "Simple is hard",       desc: "Complexity is easy. Real skill lies in distilling ideas to their essence.",                                  accent: "cya" },
      { num: "03 / HONESTY",  title: "Real conversations",   desc: "I don't tell clients what they want to hear. If a concept isn't right, I'll say so.",                       accent: "pnk" },
      { num: "04 / SYSTEMS",  title: "Think in systems",     desc: "Great design scales. I build with components and patterns that grow with your product.",                     accent: "ind" },
      { num: "05 / EMPATHY",  title: "User-first always",    desc: "Every decision starts with: how does this serve the person on the other side of the screen?",               accent: "cya" },
      { num: "06 / CURIOSITY","title": "Always learning",    desc: "I spend part of every week exploring new techniques, tools, and creative territories.",                      accent: "pnk" }
    ],
    designSkills: [
      { name: "UI/UX Design",    pct: 92 },
      { name: "Brand Identity",  pct: 85 },
      { name: "Motion Graphics", pct: 78 },
      { name: "Design Systems",  pct: 88 }
    ],
    devSkills: [
      { name: "Frontend Dev",    pct: 88 },
      { name: "React / Next.js", pct: 82 },
      { name: "CSS / Animation", pct: 90 },
      { name: "Three.js/WebGL",  pct: 65 }
    ],
    designTools: ["Figma","Adobe XD","Illustrator","Photoshop","After Effects","Framer","Webflow"],
    devStack:    ["React","Next.js","TypeScript","Tailwind","GSAP","Three.js","Node.js"],
    facts: [
      { icon: "☕", title: "Coffee-powered",  sub: "3–4 cold brews a day fuel every project" },
      { icon: "🎮", title: "Gamer at heart",  sub: "Dark Souls taught me everything about UX feedback" },
      { icon: "📚", title: "Avid reader",     sub: "Psychology, sci-fi, and design theory" },
      { icon: "🌍", title: "12 countries",    sub: "Clients from Bangladesh to San Francisco" },
      { icon: "🎵", title: "Music while coding", sub: "Synthwave and lo-fi are non-negotiables" },
      { icon: "🌙", title: "Night owl",       sub: "Best creative ideas hit at 2 AM" },
      { icon: "⚡", title: "Fast responder",  sub: "Average reply time under 2 hours" },
      { icon: "🎨", title: "6+ years deep",  sub: "Still excited about design every single day" }
    ]
  },
  work: {
    hero: {
      tag:   "// PORTFOLIO",
      title: "Selected Work",
      sub:   "A curated collection of projects across UI/UX design, frontend development, branding, and beyond."
    },
    stats: [
      { num: "42+", label: "PROJECTS" },
      { num: "28+", label: "CLIENTS" },
      { num: "12+", label: "COUNTRIES" },
      { num: "6+",  label: "YEARS" }
    ],
    featured: {
      title: "NeoBank UI Overhaul",
      badge: "FEATURED · 2025",
      type:  "UI/UX DESIGN · FINTECH",
      desc:  "Complete redesign of a digital bank's mobile and web platforms — from research through to a production-ready design system. Resulted in a 40% increase in onboarding completion.",
      tags:  [{ label: "Figma", accent: "ind" }, { label: "React", accent: "cya" }, { label: "Design System", accent: "ind" }, { label: "Fintech", accent: "pnk" }],
      stats: [{ num: "+40%", label: "CONVERSION LIFT" }, { num: "+28%", label: "DAU GROWTH" }, { num: "12wk", label: "DELIVERY" }],
      img:   "https://images.unsplash.com/photo-1551434678-e076c223a692?w=800&q=80&fit=crop"
    },
    projects: [
      { title: "Cipher Labs Identity",   sub: "Full brand system · Deep-tech startup · 2024", cat: "BRANDING",       accent: "pnk", tags: ["Brand","Illustrator","Typography"], category: "brand", img: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=600&q=80&fit=crop" },
      { title: "AR Product Visualizer",  sub: "E-commerce 3D viewer · 2024",                  cat: "3D / WEB",       accent: "cya", tags: ["Three.js","WebGL","UX"],           category: "3d",    img: "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=600&q=80&fit=crop" },
      { title: "HealthTrack Mobile App", sub: "Health & fitness platform · 2024",              cat: "UI/UX",          accent: "ind", tags: ["Figma","React Native"],            category: "ui",    img: "https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?w=600&q=80&fit=crop" },
      { title: "Nexus Design System",    sub: "SaaS component library · 2023",                 cat: "DESIGN SYSTEM",  accent: "ind", tags: ["React","Storybook","Tokens"],      category: "dev",   img: "https://images.unsplash.com/photo-1555949963-ff9fe0c870cb?w=600&q=80&fit=crop" },
      { title: "Pulse Music App",        sub: "Music streaming interface · 2023",              cat: "UI/UX",          accent: "pnk", tags: ["UI Design","Prototype"],           category: "ui",    img: "https://images.unsplash.com/photo-1542744095-fcf48d80b0fd?w=600&q=80&fit=crop" },
      { title: "Orbital Tech Rebrand",   sub: "B2B SaaS brand identity · 2023",               cat: "BRANDING",       accent: "cya", tags: ["Strategy","Logo","Guidelines"],    category: "brand", img: "https://images.unsplash.com/photo-1504639725590-34d0984388bd?w=600&q=80&fit=crop" }
    ]
  },
  services: {
    hero: {
      title: "Services & Expertise",
      sub:   "End-to-end creative and technical solutions for brands, startups, and product teams. From concept to launch — and everything in between."
    },
    items: [
      { num:"01", icon:"◻", title:"UI/UX Design",        accent:"ind", price:"FROM $2,400", desc:"Research-driven, pixel-perfect interface design. From wireframes to polished final designs.", list:["User research & journey mapping","Wireframing & interactive prototypes","High-fidelity UI design in Figma","Usability testing & iteration","Design handoff & developer specs"] },
      { num:"02", icon:"⚡", title:"Frontend Development", accent:"cya", price:"FROM $3,200", desc:"Clean, performant code that brings your designs to life. React and Next.js builds.", list:["React / Next.js development","CSS animations & micro-interactions","Performance optimization","Responsive & accessible code","CMS integration (Sanity, Contentful)"] },
      { num:"03", icon:"◈", title:"Brand Identity",       accent:"pnk", price:"FROM $1,800", desc:"Complete visual identity systems that make your brand unforgettable.", list:["Brand strategy & positioning","Logo & visual identity design","Color, typography & icon systems","Brand guidelines document","Collateral & application design"] },
      { num:"04", icon:"⊞", title:"Design Systems",       accent:"ind", price:"FROM $4,500", desc:"Scalable component libraries and design tokens that keep your product consistent.", list:["Component library in Figma","Design tokens & variables","React component library","Documentation & guidelines","Accessibility audit & WCAG compliance"] },
      { num:"05", icon:"▷", title:"Motion & Animation",   accent:"cya", price:"FROM $1,200", desc:"Purposeful motion design that enhances UX and brings your interface to life.", list:["UI micro-interactions & transitions","Lottie / web animation","After Effects animations","GSAP / Framer Motion","Loading screens & splash animations"] },
      { num:"06", icon:"◬", title:"Design Consulting",    accent:"pnk", price:"$200/hr",     desc:"Strategic guidance for teams building digital products.", list:["Product & UX audits","Design process consulting","Team workshops & training","Hiring & portfolio reviews","Ongoing advisory retainers"] }
    ],
    process: [
      { num:"01", title:"Discover", desc:"Deep-dive into your goals, users, and challenges. Research, stakeholder interviews, and success metrics.", accent:"ind" },
      { num:"02", title:"Define",   desc:"Translate research into a clear direction. Information architecture, user flows, and creative brief.", accent:"cya" },
      { num:"03", title:"Design",   desc:"Wireframes to high-fidelity. Iterative design with regular feedback and usability testing.", accent:"pnk" },
      { num:"04", title:"Deliver",  desc:"Polished deliverables, thorough documentation, developer handoff, and post-launch support.", accent:"mix" }
    ],
    pricing: [
      { badge:"STARTER", name:"Essential", amount:"$2,400", period:"per project", accent:"base", desc:"Perfect for focused, single-service projects.", features:["1 core deliverable","2 revision rounds","7–14 day delivery","Figma source files","Email support"] },
      { badge:"POPULAR",  name:"Pro",       amount:"$6,800", period:"per project", accent:"pro",  desc:"Full-service design and development engagement.", features:["Design + development","Unlimited revisions","30-day delivery","All source files","Priority support","2 weeks post-launch"] },
      { badge:"SCALE",    name:"Enterprise",amount:"Custom", period:"let's talk",  accent:"ent",  desc:"Ongoing partnership for growing teams.", features:["Monthly retainer","Dedicated hours","Weekly syncs","Full team access","Strategy sessions","SLA guarantee"] }
    ],
    faq: [
      { q:"How long does a typical project take?",       a:"Design-only projects: 2–4 weeks. Full design + development: 6–12 weeks. Timelines depend on scope and feedback speed." },
      { q:"Do you work with international clients?",     a:"Yes — I've worked with clients across 12 countries. I'm comfortable with async workflows and flexible on time zones." },
      { q:"What do you need to get started?",            a:"A brief, your goals, any existing brand assets, and a clear timeline. I'll handle the rest with a detailed discovery process." },
      { q:"Do you offer maintenance after delivery?",    a:"Yes, through monthly retainer packages. I also offer a 2-week post-launch support window included in Pro engagements." }
    ]
  },
  experience: {
    hero: {
      title: "My Journey",
      sub:   "6+ years of building, designing, and shipping digital products.",
      yearsExp: "6+",
      projects: "42+",
      clients:  "28+"
    },
    timeline: [
      { date:"2022 – PRESENT", role:"Senior Creative Freelancer", company:"Self-Employed · Remote",         desc:"End-to-end creative and technical projects for startups, scale-ups, and enterprise clients across fintech, SaaS, health, and creative industries.",                                              tags:["UI/UX","React","Brand","Strategy"],         accent:"ind" },
      { date:"2019 – 2022",    role:"Lead UI/UX Designer",        company:"Nexus Digital Studio · Dhaka",   desc:"Led a team of 5 designers building digital products for Series A–C startups. Introduced Figma design systems and built out the studio's front-end capability.",                              tags:["Leadership","Figma","Design Systems"],      accent:"cya" },
      { date:"2017 – 2019",    role:"Frontend Developer",         company:"Orbit Agency · Dhaka",           desc:"Built responsive web interfaces and marketing sites for agency clients. Bridged the gap between static mockups and production code, improving delivery speed by 30%.",                       tags:["HTML/CSS","JavaScript","WordPress"],        accent:"pnk" },
      { date:"2015 – 2017",    role:"Junior Designer & Developer", company:"Pixel Foundry · Remote",        desc:"Started as a junior doing UI designs and front-end builds for small businesses. Built a diverse portfolio and developed the foundations of design thinking.",                                tags:["UI Design","Web Dev","Freelance"],          accent:"mix" }
    ],
    education: [
      { icon:"🎓", degree:"BSc in Computer Science & Engineering", school:"BRAC University",   year:"2013 – 2017 · Dhaka, Bangladesh", accent:"ind" },
      { icon:"🎨", degree:"UX Design Professional Certificate",    school:"Google / Coursera", year:"2020 · Online",                   accent:"cya" },
      { icon:"📐", degree:"Advanced Figma & Design Systems",       school:"Designlab",         year:"2021 · Online",                   accent:"ind" }
    ],
    certs: [
      { name:"Google UX Design",      issuer:"Google / Coursera", year:"2020" },
      { name:"AWS Cloud Practitioner", issuer:"Amazon Web Services", year:"2022" },
      { name:"Framer Expert",          issuer:"Framer Academy",    year:"2023" },
      { name:"WCAG Accessibility",     issuer:"IAAP",              year:"2023" },
      { name:"Next.js Developer",      issuer:"Vercel",            year:"2024" },
      { name:"Three.js Journey",       issuer:"Bruno Simon",       year:"2024" }
    ],
    skills: [
      { name:"UI/UX Design",    pct:92 },
      { name:"Frontend Dev",    pct:88 },
      { name:"Brand Identity",  pct:85 },
      { name:"Design Systems",  pct:88 },
      { name:"Motion Design",   pct:78 },
      { name:"Three.js/WebGL",  pct:65 }
    ],
    statsRow: [
      { num:"42+", label:"PROJECTS DELIVERED" },
      { num:"28+", label:"HAPPY CLIENTS" },
      { num:"12+", label:"COUNTRIES SERVED" },
      { num:"98%", label:"ON-TIME DELIVERY" }
    ]
  },
  blog: {
    hero: {
      tag:   "// THOUGHTS & WRITING",
      title: "Latest Writings",
      sub:   "Design, development, freelancing, and the creative life. Honest perspectives from someone building in the trenches."
    },
    featured: {
      title:    "The Future of Dark UI Design: Why Aurora Aesthetics Are Winning",
      cat:      "DESIGN · TRENDS",
      excerpt:  "Aurora gradients, layered depth, and frosted glass are no longer just trends — they're becoming the new standard for premium digital products. Here's why, and how to execute them without falling into cliché.",
      author:   "Muhtasim Ahmed",
      date:     "Mar 12, 2025",
      readTime: "8 MIN READ",
      img:      "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=800&q=80&fit=crop"
    },
    posts: [
      { title:"Freelancing in the Age of AI: How to Stay Relevant in 2025",           excerpt:"AI can generate UI, write copy, and produce code. So what's left for creatives? More than you think — if you know where to look.",                                                       cat:"FREELANCING", accent:"ind", date:"FEB 28, 2025", readTime:"6 MIN READ", img:"https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=500&q=80&fit=crop" },
      { title:"Building a Design System Solo: Lessons from the Trenches",              excerpt:"Creating a full token-based design system as a one-person team is simultaneously the most rewarding and most humbling thing I've done professionally.",                                    cat:"DESIGN",      accent:"cya", date:"JAN 15, 2025", readTime:"5 MIN READ", img:"https://images.unsplash.com/photo-1551434678-e076c223a692?w=500&q=80&fit=crop" },
      { title:"The Art of Micro-Interactions: Making UI Feel Alive",                   excerpt:"The hover state. The loading animation. The error shake. Small moments that separate good products from great ones.",                                                                       cat:"DEVELOPMENT", accent:"pnk", date:"DEC 20, 2024", readTime:"7 MIN READ", img:"https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?w=500&q=80&fit=crop" },
      { title:"Pricing Your Freelance Work Right: A Practical Framework",              excerpt:"Undercharging is the most common mistake freelancers make. Here's the mental model and tactical approach I use to price projects confidently.",                                             cat:"FREELANCING", accent:"ind", date:"NOV 5, 2024",  readTime:"9 MIN READ", img:"https://images.unsplash.com/photo-1504639725590-34d0984388bd?w=500&q=80&fit=crop" },
      { title:"My Full Design + Dev Stack in 2025",                                    excerpt:"From Figma variables to Next.js deployment — a complete walkthrough of every tool in my current workflow and why I chose each one.",                                                        cat:"TOOLS",       accent:"cya", date:"OCT 18, 2024", readTime:"4 MIN READ", img:"https://images.unsplash.com/photo-1542744095-fcf48d80b0fd?w=500&q=80&fit=crop" },
      { title:"Typography Rules I Wish I'd Known Earlier",                             excerpt:"Hierarchy, contrast, rhythm, and the one font-pairing formula that works for almost everything. The fundamentals that transform good design into great design.",                             cat:"DESIGN",      accent:"pnk", date:"SEP 3, 2024",  readTime:"6 MIN READ", img:"https://images.unsplash.com/photo-1555949963-ff9fe0c870cb?w=500&q=80&fit=crop" }
    ]
  },
  contact: {
    hero: {
      title: "Let's build something.",
      sub:   "Tell me about your project. I'll come back with a full proposal within 24 hours — no strings attached."
    },
    info: [
      { label:"EMAIL",          val:"hello@muhtasimahmed.dev",      sub:"Best for project inquiries",      accent:"ind", icon:"@"  },
      { label:"LOCATION",       val:"Dhaka, Bangladesh",            sub:"UTC+6 · Available globally",     accent:"cya", icon:"◎"  },
      { label:"AVAILABILITY",   val:"Available for new projects",   sub:"Next available: Immediately",    accent:"pnk", icon:"◈"  },
      { label:"WORKING HOURS",  val:"9AM – 10PM (UTC+6)",           sub:"Flexible for other time zones",  accent:"ind", icon:"🕒" }
    ],
    faq: [
      { q:"How quickly do you start?",             a:"After we align on scope, I can typically start within 3–5 business days. For urgent projects I can often start sooner — just ask." },
      { q:"What information do I need to provide?", a:"Your goals, target audience, existing brand assets, competitors you admire, and timeline. I'll ask for the rest during our discovery call." },
      { q:"Do you work with small budgets?",        a:"My minimum project size is $1,500. For smaller needs, I recommend Upwork or Contra where you'll find great talent at lower rates." },
      { q:"What's your revision policy?",           a:"Every project includes 2–3 revision rounds. Larger engagements have unlimited revisions within agreed milestones." },
      { q:"Can we do a video call first?",          a:"Absolutely — I prefer it for projects over $3K. Book one directly through my Calendly link after submitting the form." },
      { q:"Do you offer ongoing support?",          a:"Yes, through monthly retainer packages. Great for growing products that need consistent design or development support." }
    ]
  }
};

/* ─── Storage helpers ─────────────────────────────── */
function getSiteData() {
  try {
    const stored = localStorage.getItem('siteData_v2');
    if (stored) return JSON.parse(stored);
  } catch(e) {}
  return JSON.parse(JSON.stringify(DEFAULT_DATA));
}

function setSiteData(data) {
  try { localStorage.setItem('siteData_v2', JSON.stringify(data)); } catch(e) {}
}

function resetSiteData() {
  localStorage.removeItem('siteData_v2');
  return JSON.parse(JSON.stringify(DEFAULT_DATA));
}

/* Deep-get by dot path: get(obj, 'home.hero.title') */
function deepGet(obj, path) {
  return path.split('.').reduce((o,k) => (o && o[k] !== undefined ? o[k] : undefined), obj);
}

/* Deep-set by dot path: set(obj, 'home.hero.title', 'New') */
function deepSet(obj, path, value) {
  const keys = path.split('.');
  let cur = obj;
  for (let i = 0; i < keys.length - 1; i++) {
    if (cur[keys[i]] === undefined) cur[keys[i]] = {};
    cur = cur[keys[i]];
  }
  cur[keys[keys.length - 1]] = value;
}
