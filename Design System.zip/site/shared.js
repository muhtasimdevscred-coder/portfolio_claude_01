/* shared.js — Muhtasim Ahmed Portfolio */

function el(id) { return document.getElementById(id); }

function setPageTitle(pageLabel) {
  const D = getSiteData();
  document.title = D.global.name + (pageLabel ? ' — ' + pageLabel : '');
}

function addDashboardBtn() {
  if (document.querySelector('.db-fab')) return;
  const btn = document.createElement('a');
  btn.href = 'dashboard.html';
  btn.className = 'db-fab';
  btn.title = 'Open Dashboard';
  btn.innerHTML = `<span style="font-size:14px">⚙️</span><span class="db-fab-label">DASHBOARD</span>`;
  btn.style.cssText = `
    position:fixed;bottom:24px;right:24px;
    background:rgba(7,0,46,.92);
    border:1px solid rgba(99,102,241,.35);
    border-radius:12px;padding:10px 16px;
    display:flex;align-items:center;gap:8px;
    text-decoration:none;z-index:50;
    backdrop-filter:blur(12px);
    transition:all .2s;cursor:pointer;
  `;
  btn.addEventListener('mouseenter', () => {
    btn.style.borderColor = 'rgba(99,102,241,.65)';
    btn.style.background = 'rgba(99,102,241,.18)';
    btn.style.transform = 'translateY(-2px)';
  });
  btn.addEventListener('mouseleave', () => {
    btn.style.borderColor = 'rgba(99,102,241,.35)';
    btn.style.background = 'rgba(7,0,46,.92)';
    btn.style.transform = '';
  });
  const label = btn.querySelector('.db-fab-label');
  label.style.cssText = 'font-family:var(--fm);font-size:8px;color:var(--il);letter-spacing:2px';
  document.body.appendChild(btn);
}

function renderNav(activePage) {
  const D = getSiteData(), G = D.global;
  const pages = [
    { id: 'about',      label: 'ABOUT',    href: 'about.html' },
    { id: 'services',   label: 'SERVICES', href: 'services.html' },
    { id: 'work',       label: 'WORK',     href: 'work.html' },
    { id: 'experience', label: 'EXP',      href: 'experience.html' },
    { id: 'blog',       label: 'BLOG',     href: 'blog.html' },
    { id: 'contact',    label: 'CONTACT',  href: 'contact.html' }
  ];
  const nav = document.getElementById('nav');
  if (!nav) return;
  nav.innerHTML = `
    <a class="nav-logo" href="index.html">${G.logo}</a>
    <div class="nav-div"></div>
    <div class="nav-links">
      ${pages.map(p => `<a href="${p.href}"${p.id === activePage ? ' class="active"' : ''}>${p.label}</a>`).join('')}
    </div>
    <div class="nav-div"></div>
    <button class="nav-hire" onclick="location.href='contact.html'">HIRE ME</button>
  `;
}

function renderFooter() {
  const D = getSiteData(), G = D.global;
  const footer = document.getElementById('footer');
  if (!footer) return;
  footer.innerHTML = `
    <a href="index.html" class="f-logo">${G.name.toUpperCase().replace(' ','')}</a>
    <div class="f-links">
      ${G.socials.map(s => `<a href="${s.url}">${s.name.split(' ')[0].toUpperCase()}</a>`).join('')}
    </div>
    <div class="f-copy">${G.copyright}</div>
  `;
}

function initReveal() {
  const obs = new IntersectionObserver(entries => {
    entries.forEach(x => {
      if (x.isIntersecting) {
        x.target.classList.add('visible');
        obs.unobserve(x.target);
      }
    });
  }, { threshold: 0.1 });
  document.querySelectorAll('.reveal, .reveal-left, .reveal-right').forEach(el2 => {
    el2.classList.remove('visible');
    obs.observe(el2);
  });
}

function initCursor() {
  const cur = document.getElementById('cur');
  const cur2 = document.getElementById('cur2');
  if (!cur || !cur2) return;
  let mx = 0, my = 0, cx = 0, cy = 0;
  document.addEventListener('mousemove', e => {
    mx = e.clientX; my = e.clientY;
    cur.style.left = mx + 'px'; cur.style.top = my + 'px';
  });
  function animRing() {
    cx += (mx - cx) * 0.12; cy += (my - cy) * 0.12;
    cur2.style.left = cx + 'px'; cur2.style.top = cy + 'px';
    requestAnimationFrame(animRing);
  }
  animRing();
  document.addEventListener('mousedown', () => { cur.style.width = '16px'; cur.style.height = '16px'; });
  document.addEventListener('mouseup',   () => { cur.style.width = '10px'; cur.style.height = '10px'; });
}

function initScroll() {
  const nav = document.getElementById('nav');
  if (!nav) return;
  window.addEventListener('scroll', () => nav.classList.toggle('scrolled', scrollY > 60));
}

function initShared() {
  initCursor();
  initScroll();
  initReveal();
  addDashboardBtn();
  // Live edit listener from dashboard
  window.addEventListener('message', e => {
    if (e.data && e.data.type === 'liveReload') {
      if (e.data.data) setSiteData(e.data.data);
      location.reload();
    }
  });
}
